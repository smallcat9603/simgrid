C -*- Mode: Fortran; -*-
C
C  (C) 2003 by Argonne National Laboratory.
C      See COPYRIGHT in top-level directory.
C
       integer(kind=MPI_ADDRESS_KIND) extrastate, valin, valout, val
