/* Copyright (c) 2017-2018. The SimGrid Team. All rights reserved.          */

/* This program is free software; you can redistribute it and/or modify it
 * under the terms of the license (GNU LGPL) which comes with this package. */

#include "simgrid/s4u.hpp"

XBT_LOG_NEW_DEFAULT_CATEGORY(s4u_test, "Messages specific for this s4u example");

static void monitor(simgrid::s4u::ExecPtr activity)
{
  while (not activity->test()) {
    XBT_INFO("activity remaining duration: %g (%.0f%%)", activity->get_remaining(),
             100 * activity->get_remaining_ratio());
    simgrid::s4u::this_actor::sleep_for(5);
  }
  XBT_INFO("My task is over.");
}

static void executor()
{
  XBT_INFO("Create one monitored task, and wait for it");
  simgrid::s4u::ExecPtr activity = simgrid::s4u::this_actor::exec_async(1e9);
  simgrid::s4u::Actor::create("monitor 1", simgrid::s4u::Host::by_name("Tremblay"), monitor, activity);
  activity->wait(); // This blocks until the activity is over
  XBT_INFO("The monitored task is over. Let's start 3 of them now.");
  simgrid::s4u::Actor::create("monitor 2", simgrid::s4u::Host::by_name("Jupiter"), monitor,
                              simgrid::s4u::this_actor::exec_async(1e9));
  simgrid::s4u::Actor::create("monitor 3", simgrid::s4u::Host::by_name("Ginette"), monitor,
                              simgrid::s4u::this_actor::exec_async(1e9));
  simgrid::s4u::Actor::create("monitor 4", simgrid::s4u::Host::by_name("Bourassa"), monitor,
                              simgrid::s4u::this_actor::exec_async(1e9));
  XBT_INFO("All activities are started; finish now");
  // Waiting execution activities is not mandatory: they go to completion once started

  // No memory is leaked here: activities are automatically refcounted, thanks to C++ smart pointers
}

int main(int argc, char* argv[])
{
  simgrid::s4u::Engine e(&argc, argv);
  e.load_platform(argv[1]);

  simgrid::s4u::Actor::create("executor", simgrid::s4u::Host::by_name("Fafard"), executor);

  e.run();

  return 0;
}
