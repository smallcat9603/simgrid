#!/usr/bin/env bash

echo "batsim: $(batsim --version)"
echo "simgrid: $(batsim --simgrid-version)"
echo "batsched: $(batsched --version)"
echo "robin: $(robin --version)"
