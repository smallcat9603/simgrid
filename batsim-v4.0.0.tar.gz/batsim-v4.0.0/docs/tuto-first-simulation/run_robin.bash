#!/usr/bin/env bash

robin ./expe.yaml
