Logo information
================

Done by Millian Poquet with inkscape_.

Unlicensed
----------
See Unlicense_.

HACKING
-------

- Modify ``logo.svg`` with the SVG tool of your choice (e.g., inkscape_).
- Generate other versions by calling ``ninja``.

Used material
-------------

- A bat SVG found on wikipedia. Unknown author, public domain.
  https://commons.wikimedia.org/wiki/File:Bat_shadow.svg
- The *rectangle-shaped* `replay font`_ found on dafont.
  Christofer Lundholm (the author) states the font is free
  but no license is specified.

.. _inkscape: https://inkscape.org/
.. _Unlicense: http://unlicense.org/
.. _replay font: https://www.dafont.com/fr/replay.font
