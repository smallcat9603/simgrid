#!/usr/bin/env Rscript
rmarkdown::render('notebook.Rmd')
