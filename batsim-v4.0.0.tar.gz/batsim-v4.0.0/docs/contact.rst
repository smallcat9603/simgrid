.. _contact_us:

Contact us
==========

The main way to chat with the Batsim team is on `Batsim's mattermost`_.

Otherwise, the batsim-user@inria.fr mailing list allows to
ask questions and to get announcements.
Registration is done on `Inria's sympa`_.

.. _Batsim's mattermost: https://framateam.org/signup_user_complete/?id=5xb995hph3d79yj738pokxrnuh
.. _Inria's sympa: https://sympa.inria.fr/sympa/info/batsim-user
