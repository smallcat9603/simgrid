.. _todo:

TODOs
=====

Features TODOs
--------------
These are listed in our `internal issues`_.

Documentation TODOs
-------------------
.. todolist::

.. _internal issues: https://gitlab.inria.fr/batsim/batsim/issues
