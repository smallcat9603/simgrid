Batsim Code Documentation
=========================

Welcome to Batsim's code documentation !

These pages describe the different functions and types used by Batsim.<br/>
If you are more interested about how to use Batsim or how it works,
you should visit [Batsim's main documentation](https://batsim.rtfd.io).
