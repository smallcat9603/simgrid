#!/bin/sh
# for deleting links of common sources
set -e

rm -f SFMT.f90
rm -f common.f90
rm -f common_mpi.f90
rm -f common_mtx.f90
rm -f common_letkf.f90
rm -f netlib.f
rm -f netlibblas.f

rm -f common_speedy.f90
rm -f common_mpi_speedy.f90
rm -f common_obs_speedy.f90

