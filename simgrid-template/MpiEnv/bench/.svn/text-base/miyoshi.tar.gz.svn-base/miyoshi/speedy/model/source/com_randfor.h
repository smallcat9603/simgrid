C--
C--   /RANDF/ Random diabatic forcing (initial. in INIRDF) 
      COMMON /RANDF/ RANDFH(NGP,2), RANDFV(NLEV,2)

