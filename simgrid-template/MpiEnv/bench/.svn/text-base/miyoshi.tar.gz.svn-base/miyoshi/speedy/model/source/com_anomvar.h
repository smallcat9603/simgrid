
      common /sfconst/ rhcap(3), stdis(3), flxice,
     &                 rhcap2(ix,il,2), wobsst(ix,il)

      common /sfcanom/ stanom(ix,il,3), sstan(ix,il) 

      common /sfcflux/ hfint(ix,il,2) 
