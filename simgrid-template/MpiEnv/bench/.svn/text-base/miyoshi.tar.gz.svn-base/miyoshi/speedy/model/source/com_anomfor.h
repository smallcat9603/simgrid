
      common /sstanom/ sstan2(ix,il,2),
     &                 sstan1(ix,il)

      common /heatflx/ hflxl12(ix,il,12), hflxs12(ix,il,12),
     &                 hflxl1(ix,il),     hflxs1(ix,il)
