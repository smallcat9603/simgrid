
      common /anom/ sstanom(ix,il,2),
     &              sstan1 (ix,il)
