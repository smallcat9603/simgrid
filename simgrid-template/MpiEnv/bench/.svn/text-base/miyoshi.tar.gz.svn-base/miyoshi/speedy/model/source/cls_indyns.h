C--
C--   Reference vertical profiles of temperature and humidity
C--   and horizontal diffusion constants (common DYNC0)

      GAMMA  = 6.
      HSCALE = 7.5
      HSHUM  = 2.5
      REFRH1 = 0.7

      THD    = 18.
      THDD   =  9.
      THDS   = 12.
      TDRS   = 24.*30.
