C--
C--   /DATE1/: date and time variables (updated in FORDATE)
      common /DATE1/ IYEAR, IMONTH, IDAY, FDAY, TYEAR
