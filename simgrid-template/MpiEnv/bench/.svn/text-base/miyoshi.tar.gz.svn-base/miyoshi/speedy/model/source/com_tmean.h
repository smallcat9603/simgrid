C--
C--   /TMSAVE/ : Arrays for the computation of time-means
C--              (initial./updated in TMINC and TMOUT)
      COMMON /TMSAVE/ SAVE2D(NGP,NS2D), SAVE3D(NGP,NLEV,NS3D),
     &                FACT2D(NS2D)
     
