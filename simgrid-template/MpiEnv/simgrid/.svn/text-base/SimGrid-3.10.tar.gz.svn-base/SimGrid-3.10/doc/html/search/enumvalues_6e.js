var searchData=
[
  ['network_5ferror',['network_error',['../group__XBT__ex.html#ggaa45fec59aa57056784554a7f998f0854afa15abb01e5f46363458529588f0d871',1,'ex.h']]],
  ['not_5ffound_5ferror',['not_found_error',['../group__XBT__ex.html#ggaa45fec59aa57056784554a7f998f0854a2a966e9e887d3ab79628272781200439',1,'ex.h']]]
];
