var group__SIMIX__API =
[
    [ "SIMIX datatypes management details", "group__m__datatypes__management__details.html", null ],
    [ "Process Management Functions", "group__simix__process__management.html", "group__simix__process__management" ],
    [ "Host Management Functions", "group__simix__host__management.html", "group__simix__host__management" ],
    [ "RDV Management Functions", "group__simix__rdv__management.html", "group__simix__rdv__management" ],
    [ "Communication Management Functions", "group__simix__comm__management.html", null ],
    [ "Synchronisation Management Functions", "group__simix__synchro__management.html", null ],
    [ "File Management Functions", "group__simix__file__management.html", "group__simix__file__management" ],
    [ "SIMIX_global_init", "group__SIMIX__API.html#ga61a5c57ccf08e71bac21571b94ec1a38", null ],
    [ "SIMIX_clean", "group__SIMIX__API.html#gaf764507fe3726a890a8657d5db2eaffc", null ],
    [ "SIMIX_get_clock", "group__SIMIX__API.html#ga8298a6bf3cdb667f2aca7b1cfd9b2eb8", null ],
    [ "SIMIX_run", "group__SIMIX__API.html#gaebdd718ef8f26134756d5fa6de1ff854", null ]
];