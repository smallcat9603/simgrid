var structs__model__type =
[
    [ "name", "structs__model__type.html#a3c16d53c35bc1d4bfd1fac73347b9112", null ],
    [ "desc", "structs__model__type.html#a8f34c752019a99c8e45ddd39e92b2b38", null ],
    [ "create", "structs__model__type.html#afb355965926bc9d620da6847710f6a12", null ],
    [ "end", "structs__model__type.html#a511f15d145ff07393d09864a768f0bbc", null ]
];