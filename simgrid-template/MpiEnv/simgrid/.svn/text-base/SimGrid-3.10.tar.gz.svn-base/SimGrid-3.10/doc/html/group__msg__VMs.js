var group__msg__VMs =
[
    [ "MSG_vm_start", "group__msg__VMs.html#ga407fdb335bb6adbe52eab4055ee4676b", null ],
    [ "MSG_vms_as_dynar", "group__msg__VMs.html#ga9d66095e9599545ab4cdd787a38f6b8e", null ],
    [ "MSG_vm_is_suspended", "group__msg__VMs.html#gac7919295b7c197a43717e367f9c115c5", null ],
    [ "MSG_vm_is_running", "group__msg__VMs.html#ga6ba8320c7a90ed67d3c8e2079460b8a9", null ],
    [ "MSG_vm_bind", "group__msg__VMs.html#ga21d8a296f64c7190dcbcfd0c249b4275", null ],
    [ "MSG_vm_unbind", "group__msg__VMs.html#gaf65aa7a4497fceaa50414caff2772a05", null ],
    [ "MSG_vm_migrate", "group__msg__VMs.html#ga0b701b7e5a4b0459f1b9326e188e19b0", null ],
    [ "MSG_vm_suspend", "group__msg__VMs.html#ga32243e8be24c253c0367c81d0289e057", null ],
    [ "MSG_vm_resume", "group__msg__VMs.html#ga9815e54a5e6cdf849d4847803d377e19", null ],
    [ "MSG_vm_shutdown", "group__msg__VMs.html#ga1a40d2652506f4576408e35346cd3cff", null ],
    [ "MSG_vm_reboot", "group__msg__VMs.html#ga6e665c9d3b9c0a6b3e9a97a419a7861f", null ],
    [ "MSG_vm_destroy", "group__msg__VMs.html#gae493c978235ba8efeee6d8b5a5286e5b", null ]
];