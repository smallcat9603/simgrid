var searchData=
[
  ['usual_20data_20structures',['Usual data structures',['../group__XBT__adt.html',1,'']]],
  ['user_20interface_3a_20changing_20values',['User interface: changing values',['../group__XBT__cfg__use.html',1,'']]],
  ['unit_20testing_20support',['Unit testing support',['../group__XBT__cunit.html',1,'']]]
];
