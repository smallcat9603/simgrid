var group__msg__synchro =
[
    [ "msg_sem_t", "group__msg__synchro.html#gadb025f3f21a31a3140675cea7a4ef957", null ],
    [ "MSG_sem_init", "group__msg__synchro.html#gaa540fb0fe72d3bf3b4183ba3c6e07faa", null ],
    [ "MSG_sem_acquire", "group__msg__synchro.html#ga6baf039cbe49f8d83b8d5423f463f4bc", null ],
    [ "MSG_sem_acquire_timeout", "group__msg__synchro.html#gad080078a175bc7f88618970b07dd445b", null ],
    [ "MSG_sem_release", "group__msg__synchro.html#ga47ed8c02cacfe486d3fa7d29beb56af1", null ],
    [ "MSG_sem_would_block", "group__msg__synchro.html#ga46b0858501af3424a570f8d786320520", null ]
];