var group__XBT__dict__nnul =
[
    [ "xbt_dict_set_ext", "group__XBT__dict__nnul.html#gac10a4d2fd3a86576c1be1b61811317d8", null ],
    [ "xbt_dict_get_ext", "group__XBT__dict__nnul.html#ga7e5810ce5387ee78e25bb92c206deacd", null ],
    [ "xbt_dict_get_or_null_ext", "group__XBT__dict__nnul.html#gabfcc7b250b01f46a4397946a7a104fd1", null ],
    [ "xbt_dict_remove_ext", "group__XBT__dict__nnul.html#gad36d0be75e939e85ee17a9756332b6c4", null ]
];