var group__XBT__grounding =
[
    [ "Malloc and friends", "group__XBT__syscall.html", "group__XBT__syscall" ],
    [ "String related functions", "group__XBT__str.html", "group__XBT__str" ],
    [ "Exception support", "group__XBT__ex.html", "group__XBT__ex" ],
    [ "Logging support", "group__XBT__log.html", "group__XBT__log" ],
    [ "Assert macro familly", "group__XBT__error.html", "group__XBT__error" ],
    [ "Configuration support", "group__XBT__config.html", "group__XBT__config" ],
    [ "Mallocators", "group__XBT__mallocator.html", "group__XBT__mallocator" ],
    [ "Unit testing support", "group__XBT__cunit.html", "group__XBT__cunit" ]
];