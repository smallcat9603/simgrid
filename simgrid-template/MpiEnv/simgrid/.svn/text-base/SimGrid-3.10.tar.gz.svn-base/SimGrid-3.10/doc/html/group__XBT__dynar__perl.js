var group__XBT__dynar__perl =
[
    [ "xbt_dynar_push", "group__XBT__dynar__perl.html#gac89da4c2c302218759c7fe477d8eacc0", null ],
    [ "xbt_dynar_pop", "group__XBT__dynar__perl.html#ga37d2b11c522e02ede79a12a89575ceb1", null ],
    [ "xbt_dynar_unshift", "group__XBT__dynar__perl.html#ga3499315d48944f3bfaf6aeea1e2c75e8", null ],
    [ "xbt_dynar_shift", "group__XBT__dynar__perl.html#ga2966d02b350ef985447c4053c258a1a0", null ],
    [ "xbt_dynar_map", "group__XBT__dynar__perl.html#ga02bb7b95aaa0fe03c26222f65566e744", null ]
];