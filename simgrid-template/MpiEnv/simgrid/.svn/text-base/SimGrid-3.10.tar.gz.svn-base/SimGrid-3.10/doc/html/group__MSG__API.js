var group__MSG__API =
[
    [ "Main MSG simulation Functions", "group__msg__simulation.html", "group__msg__simulation" ],
    [ "Process Management Functions", "group__m__process__management.html", "group__m__process__management" ],
    [ "Host Management Functions", "group__m__host__management.html", "group__m__host__management" ],
    [ "Task Management Functions", "group__m__task__management.html", "group__m__task__management" ],
    [ "Mailbox Management Functions", "group__msg__mailbox__management.html", "group__msg__mailbox__management" ],
    [ "Task Actions", "group__msg__task__usage.html", "group__msg__task__usage" ],
    [ "Explicit Synchronization Functions", "group__msg__synchro.html", "group__msg__synchro" ],
    [ "VMs", "group__msg__VMs.html", "group__msg__VMs" ],
    [ "File Management Functions", "group__msg__file__management.html", "group__msg__file__management" ],
    [ "Trace-driven simulations", "group__msg__trace__driven.html", "group__msg__trace__driven" ],
    [ "Lua bindings", "group__MSG__LUA.html", null ],
    [ "MSG examples", "group__MSG__examples.html", null ],
    [ "MSG Deprecated", "group__msg__deprecated__functions.html", "group__msg__deprecated__functions" ]
];