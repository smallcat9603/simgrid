var group__XBT__adt =
[
    [ "Dynar: generic dynamic array", "group__XBT__dynar.html", "group__XBT__dynar" ],
    [ "Dict: generic dictionnary", "group__XBT__dict.html", "group__XBT__dict" ],
    [ "Set: generic set datatype", "group__XBT__set.html", "group__XBT__set" ],
    [ "Fifo: generic workqueue", "group__XBT__fifo.html", "group__XBT__fifo" ],
    [ "Swag: O(1) set datatype", "group__XBT__swag.html", "group__XBT__swag" ],
    [ "Heap: generic heap data structure", "group__XBT__heap.html", "group__XBT__heap" ],
    [ "Data description", "group__XBT__dd.html", null ]
];