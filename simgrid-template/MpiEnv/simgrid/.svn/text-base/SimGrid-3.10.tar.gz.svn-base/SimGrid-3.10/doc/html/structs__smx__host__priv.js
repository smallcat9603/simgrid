var structs__smx__host__priv =
[
    [ "process_list", "structs__smx__host__priv.html#a7fbfb83e72a87b2ea799f04fb8bdb885", null ],
    [ "auto_restart_processes", "structs__smx__host__priv.html#a67288fcbea0dd351511ef07fad244a37", null ],
    [ "data", "structs__smx__host__priv.html#acf592831b265f0480ccab9d3d649cf35", null ]
];