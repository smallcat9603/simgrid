var internals =
[
    [ "Overview of the toolkit components", "internals.html#ug_overview", [
      [ "Programmation environments layer", "internals.html#ug_overview_envs", null ],
      [ "Simulation kernel layer", "internals.html#ug_overview_kernel", null ],
      [ "Base layer", "internals.html#ug_overview_fondation", null ],
      [ "Tracing simulation", "internals.html#ug_lucas_layer", null ]
    ] ],
    [ "Documenting SimGrid", "inside_doxygen.html", [
      [ "Adding a new module to the reference guide", "inside_doxygen.html#inside_doxygen_module", [
        [ "Declaring the module to doxygen", "inside_doxygen.html#inside_doxygen_module_create", null ],
        [ "Adding symbols to your module", "inside_doxygen.html#inside_doxygen_module_populate", null ],
        [ "Documenting the symbols of your module", "inside_doxygen.html#inside_doxygen_module_document", null ]
      ] ],
      [ "Adding a new page to the user guide", "inside_doxygen.html#inside_doxygen_page", [
        [ "Writing a new documentation page", "inside_doxygen.html#inside_doxygen_page_write", null ],
        [ "Registering a documentation page to doxygen", "inside_doxygen.html#inside_doxygen_page_doxy", null ],
        [ "Registering a documentation page to cmake", "inside_doxygen.html#inside_doxygen_page_cmake", null ]
      ] ],
      [ "Adding an image to the documentation", "inside_doxygen.html#inside_doxygen_image", null ],
      [ "Working on the website", "inside_doxygen.html#inside_doxygen_website", null ],
      [ "Regenerating the documentation", "inside_doxygen.html#inside_doxygen_regen", null ]
    ] ],
    [ "Extending SimGrid", "inside_extending.html", [
      [ "How to add a new MSG function?", "inside_extending.html#simgrid_dev_guide_api", null ],
      [ "How to add a new model in surf?", "inside_extending.html#simgrid_dev_guide_model", null ],
      [ "How to add a new simcall?", "inside_extending.html#simgrid_dev_guide_simcall", null ],
      [ "What is How to add a new tag for xml files?", "inside_extending.html#simgrid_dev_guide_tag", null ]
    ] ],
    [ "Modifying the cmake files", "inside_cmake.html", [
      [ "Generalities on Cmake", "inside_cmake.html#inside_cmake_intro", [
        [ "What is Cmake?", "inside_cmake.html#inside_cmake_what", null ],
        [ "Why cmake?", "inside_cmake.html#inside_cmake_why", null ]
      ] ],
      [ "How to add source files?", "inside_cmake.html#inside_cmake_addsrc", null ],
      [ "How to add examples?", "inside_cmake.html#cmake_dev_guide_ex", null ],
      [ "How to add tests?", "inside_cmake.html#inside_cmake_addtest", [
        [ "Unit testing in SimGrid", "inside_cmake.html#inside_cmake_addtest_unit", null ],
        [ "Integration testing in SimGrid", "inside_cmake.html#inside_cmake_addtest_integration", null ],
        [ "Performance testing in SimGrid", "inside_cmake.html#inside_cmake_addtest_perf", null ]
      ] ]
    ] ],
    [ "SimGrid Developer Guide - Releasing", "inside_release.html", [
      [ "Releasing the main library", "inside_release.html#inside_release_c", [
        [ "Before releasing", "inside_release.html#inside_release_c_preconditions", null ],
        [ "Building the source archive", "inside_release.html#inside_release_c_source", null ],
        [ "Binary distribution under Win32", "inside_release.html#inside_release_c_win32", null ],
        [ "Check list after releasing", "inside_release.html#inside_release_c_postchecks", null ]
      ] ],
      [ "Releasing the bindings", "inside_release.html#inside_release_bindings", null ]
    ] ],
    [ "Automatic Testing Infrastructure", "inside_autotests.html", [
      [ "How to run test in pipol?", "inside_autotests.html#xps_dev_guide_pipol", [
        [ "What is PIPOL?", "inside_autotests.html#inside_autotests_dev_guide_pipol_general", null ],
        [ "From PIPOL frontend", "inside_autotests.html#inside_autotests_dev_guide_pipol_frontend", null ],
        [ "From a computer", "inside_autotests.html#inside_autotests_dev_guide_pipol_home", null ]
      ] ],
      [ "How to use nightly builds?", "inside_autotests.html#inside_autotests_dev_guide_pipol_nightly", null ],
      [ "How to report tests in cdash?", "inside_autotests.html#inside_autotests_dev_guide_cdash", null ],
      [ "Infrastructure of the SimGrid Performance Regresion tests", "inside_autotests.html#inside_autotests_perf", [
        [ "How to execute g5k campaign?", "inside_autotests.html#inside_autotests_dev_guide_g5k_campaign", null ],
        [ "How to analyze logs?", "inside_autotests.html#inside_autotests_dev_guide_g5k_log", null ]
      ] ]
    ] ]
];