var group__XBT__cfg__decl =
[
    [ "xbt_boolean_couple", "structxbt__boolean__couple.html", null ],
    [ "xbt_cfg_cb_t", "group__XBT__cfg__decl.html#ga4080887ffe36fb58611ee70094c003be", null ],
    [ "e_xbt_cfgelm_type_t", "group__XBT__cfg__decl.html#gaae016e87dc6935ed51617bbea7b8aa6c", [
      [ "xbt_cfgelm_int", "group__XBT__cfg__decl.html#ggaae016e87dc6935ed51617bbea7b8aa6caf101f0c7af43525d4a07e9bcb5d3b7f2", null ],
      [ "xbt_cfgelm_double", "group__XBT__cfg__decl.html#ggaae016e87dc6935ed51617bbea7b8aa6ca35412ca92ec3591c76f5403810aed6f3", null ],
      [ "xbt_cfgelm_string", "group__XBT__cfg__decl.html#ggaae016e87dc6935ed51617bbea7b8aa6cac8df732d454a4bc85379de2c154a737e", null ],
      [ "xbt_cfgelm_boolean", "group__XBT__cfg__decl.html#ggaae016e87dc6935ed51617bbea7b8aa6cab46f486cddae583964bd0667fabb269b", null ],
      [ "xbt_cfgelm_peer", "group__XBT__cfg__decl.html#ggaae016e87dc6935ed51617bbea7b8aa6ca79bd0045369cbc55fe7191a28d31d168", null ]
    ] ],
    [ "xbt_cfg_new", "group__XBT__cfg__decl.html#ga25f767ddf162fcf5cf45c2aac58f47b8", null ],
    [ "xbt_cfg_cpy", "group__XBT__cfg__decl.html#gac679f68b23823dc08aceaefaf9b372da", null ],
    [ "xbt_cfg_free", "group__XBT__cfg__decl.html#ga67592bfbe600c89f45f40ceeb7df2c9a", null ],
    [ "xbt_cfg_dump", "group__XBT__cfg__decl.html#ga9ef64a88e6fa46d78938b32247a29528", null ]
];