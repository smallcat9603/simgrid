var group__m__host__management =
[
    [ "msg_host_t", "group__m__host__management.html#ga0cc2134715cceaeea82df1c1305fbecf", null ],
    [ "MSG_host_set_data", "group__m__host__management.html#gab52e164f5e7710facf114234152cfe85", null ],
    [ "MSG_host_get_data", "group__m__host__management.html#ga074e447602d8c0eab3f442c78a1dfe5f", null ],
    [ "MSG_host_get_name", "group__m__host__management.html#gad4daf43406f4dce8caae5310cdf40bde", null ],
    [ "MSG_host_self", "group__m__host__management.html#ga8552d95b844f896978eca735cbd73e9f", null ],
    [ "MSG_get_host_number", "group__m__host__management.html#gaafceb2773bb9e39878592ff9a9a81a01", null ],
    [ "MSG_hosts_as_dynar", "group__m__host__management.html#gaa886b8367e635efe11211b2aca5a1d43", null ],
    [ "MSG_get_host_msgload", "group__m__host__management.html#ga94b03ec6fe7c2bbf3c6c7bef2f89ee0b", null ],
    [ "MSG_get_host_speed", "group__m__host__management.html#ga6e910e3a884ebbe0b8ccae3277619374", null ],
    [ "MSG_host_get_core_number", "group__m__host__management.html#gab0df78011e11a95b3318120aa950a32f", null ],
    [ "MSG_host_get_process_list", "group__m__host__management.html#ga266e69ef1f9145caea0d507b84dd8044", null ],
    [ "MSG_host_get_property_value", "group__m__host__management.html#gadcefcdecf27f1dfb19a5c2ac5a775402", null ],
    [ "MSG_host_get_properties", "group__m__host__management.html#gac5d6359399bb8c8daba83cf62f47785f", null ],
    [ "MSG_host_set_property_value", "group__m__host__management.html#ga1b84e13e966d6ec0a2c013144d33f194", null ],
    [ "MSG_get_host_power_peak_at", "group__m__host__management.html#gaadeccc6816ff0e7809fb090207fa2504", null ],
    [ "MSG_get_host_current_power_peak", "group__m__host__management.html#ga0b6fdd80f2f66ac2fec711c712981ec5", null ],
    [ "MSG_get_host_nb_pstates", "group__m__host__management.html#ga921573751f861dc32ded07521b63eae0", null ],
    [ "MSG_set_host_power_peak_at", "group__m__host__management.html#ga2befbe7955de345ce7e02556f21bb7b4", null ],
    [ "MSG_get_host_consumed_energy", "group__m__host__management.html#ga906e9852651be55265a7c8489470e1e9", null ],
    [ "MSG_host_get_storage_list", "group__m__host__management.html#ga8398f7a284fd227c078e0d019819436b", null ]
];