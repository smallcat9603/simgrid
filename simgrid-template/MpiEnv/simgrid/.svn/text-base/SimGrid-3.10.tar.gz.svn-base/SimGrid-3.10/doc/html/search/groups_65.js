var searchData=
[
  ['explicit_20synchronization_20functions',['Explicit Synchronization Functions',['../group__msg__synchro.html',1,'']]],
  ['exception_20support',['Exception support',['../group__XBT__ex.html',1,'']]],
  ['existing_20log_20categories',['Existing log categories',['../group__XBT__log__cats.html',1,'']]]
];
