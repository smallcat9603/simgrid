var searchData=
[
  ['cancel_5ferror',['cancel_error',['../group__XBT__ex.html#ggaa45fec59aa57056784554a7f998f0854a78725e8318a373565146a9c29698eb30',1,'ex.h']]],
  ['catch',['CATCH',['../group__XBT__ex.html#gab3271e393133e395129cc74272f9fae2',1,'ex.h']]],
  ['catch_5fanonymous',['CATCH_ANONYMOUS',['../group__XBT__ex.html#ga070f91546c08b1e31c1d7184c3c9b345',1,'ex.h']]],
  ['category',['category',['../structxbt__ex__t.html#a2fdd312ae1d96663701d743283404924',1,'xbt_ex_t::category()'],['../structsurf__action.html#ad4acecd52a2d4699e5f2145225fc890d',1,'surf_action::category()']]],
  ['contributing_20to_20simgrid',['Contributing to SimGrid',['../contributing.html',1,'advanced']]],
  ['cost',['cost',['../structsurf__action.html#a240981003cb7b2ef07b822b07a3e9973',1,'surf_action']]],
  ['communication_20management_20functions',['Communication Management Functions',['../group__simix__comm__management.html',1,'']]],
  ['create_20a_20new_20api',['Create a new API',['../group__SURF__build__api.html',1,'']]],
  ['configuration_20type_20declaration_20and_20memory_20management',['Configuration type declaration and memory management',['../group__XBT__cfg__decl.html',1,'']]],
  ['configuration_20support',['Configuration support',['../group__XBT__config.html',1,'']]],
  ['cursors_20on_20dictionaries',['Cursors on dictionaries',['../group__XBT__dict__curs.html',1,'']]],
  ['cursors_20on_20dynar',['Cursors on dynar',['../group__XBT__dynar__cursor.html',1,'']]]
];
