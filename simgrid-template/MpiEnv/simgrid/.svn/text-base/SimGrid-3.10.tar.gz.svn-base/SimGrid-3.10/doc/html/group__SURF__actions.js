var group__SURF__actions =
[
    [ "surf_action", "structsurf__action.html", null ],
    [ "surf_action_state", "structsurf__action__state.html", null ],
    [ "surf_action_t", "group__SURF__actions.html#ga260ee2edb62de03ee69190f03a9b7eba", null ],
    [ "s_surf_action_t", "group__SURF__actions.html#gae49733011b74942c0a896745bc825e92", null ],
    [ "s_surf_action_state_t", "group__SURF__actions.html#gafbcc9ab9767482d92f8709d78858d2ae", null ],
    [ "e_surf_action_state_t", "group__SURF__actions.html#gab9ef4042b1b038be1b792366de0121b2", [
      [ "SURF_ACTION_READY", "group__SURF__actions.html#ggab9ef4042b1b038be1b792366de0121b2a6caf5e4bd35cab4890c662fdaf8d3812", null ],
      [ "SURF_ACTION_RUNNING", "group__SURF__actions.html#ggab9ef4042b1b038be1b792366de0121b2a101d6224ad7c2a615c452c8c36d8a7e7", null ],
      [ "SURF_ACTION_FAILED", "group__SURF__actions.html#ggab9ef4042b1b038be1b792366de0121b2abf420e6385e8eeda58721c3e28bd919e", null ],
      [ "SURF_ACTION_DONE", "group__SURF__actions.html#ggab9ef4042b1b038be1b792366de0121b2acef3187aad961798010f295bbbd932bf", null ],
      [ "SURF_ACTION_TO_FREE", "group__SURF__actions.html#ggab9ef4042b1b038be1b792366de0121b2aa66f387221d049fbce374c4dc27629c8", null ],
      [ "SURF_ACTION_NOT_IN_THE_SYSTEM", "group__SURF__actions.html#ggab9ef4042b1b038be1b792366de0121b2a20a007bd143ea5c870c26a389ffe95e9", null ]
    ] ]
];