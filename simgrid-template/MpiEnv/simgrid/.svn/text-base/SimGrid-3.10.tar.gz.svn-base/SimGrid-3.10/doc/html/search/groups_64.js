var searchData=
[
  ['data_20description',['Data description',['../group__XBT__dd.html',1,'']]],
  ['dict_3a_20generic_20dictionnary',['Dict: generic dictionnary',['../group__XBT__dict.html',1,'']]],
  ['dictionaries_20basic_20usage',['Dictionaries basic usage',['../group__XBT__dict__basic.html',1,'']]],
  ['dict_20constructor_20and_20destructor',['Dict constructor and destructor',['../group__XBT__dict__cons.html',1,'']]],
  ['dictionaries_20with_20non_2dnul_20terminated_20keys',['Dictionaries with non-nul terminated keys',['../group__XBT__dict__nnul.html',1,'']]],
  ['dynar_3a_20generic_20dynamic_20array',['Dynar: generic dynamic array',['../group__XBT__dynar.html',1,'']]],
  ['dynar_20as_20a_20regular_20array',['Dynar as a regular array',['../group__XBT__dynar__array.html',1,'']]],
  ['dynar_20constructor_20and_20destructor',['Dynar constructor and destructor',['../group__XBT__dynar__cons.html',1,'']]],
  ['direct_20manipulation_20to_20the_20dynars_20content',['Direct manipulation to the dynars content',['../group__XBT__dynar__ctn.html',1,'']]],
  ['dynar_20miscellaneous_20functions',['Dynar miscellaneous functions',['../group__XBT__dynar__misc.html',1,'']]],
  ['direct_20access_20to_20fifo_20elements',['Direct access to fifo elements',['../group__XBT__fifo__direct.html',1,'']]]
];
