var group__XBT__peer =
[
    [ "s_xbt_peer", "structs__xbt__peer.html", null ],
    [ "xbt_peer_t", "group__XBT__peer.html#gad2304165af1ed80fe6d82eb14343eca7", null ],
    [ "s_xbt_peer_t", "group__XBT__peer.html#ga6d62b8bce4ac8f6206f66f8dd34d2532", null ],
    [ "xbt_peer_new", "group__XBT__peer.html#ga2d87fccb2ac0c6f71db29ed857b01eb2", null ],
    [ "xbt_peer_from_string", "group__XBT__peer.html#ga0d8d75aed70cb99a925b8974ce8ce4e4", null ],
    [ "xbt_peer_copy", "group__XBT__peer.html#ga9bc5b54374abccaff888cd3852c85702", null ],
    [ "xbt_peer_free", "group__XBT__peer.html#ga251d6140c311d7c04e503e3d463adba4", null ],
    [ "xbt_peer_free_voidp", "group__XBT__peer.html#ga793bb9b0c2ee6221c8e9b7d3c886dbb9", null ]
];