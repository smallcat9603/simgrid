var group__XBT__thread =
[
    [ "xbt_os_thread_t", "group__XBT__thread.html#ga7994e3241b60f854c77043c49a83873c", null ],
    [ "xbt_os_mutex_t", "group__XBT__thread.html#ga51b6d74f9dcfa8d7563ddf6386f9bd89", null ],
    [ "xbt_os_rmutex_t", "group__XBT__thread.html#gaac45eea7caeae848b86cf78d989d9aee", null ],
    [ "xbt_os_cond_t", "group__XBT__thread.html#ga2c6224cb25614dc8b972aca6288ebe60", null ],
    [ "xbt_os_sem_t", "group__XBT__thread.html#gab48cac979eebc8c1e26ca7adc7cec0ac", null ],
    [ "xbt_os_thread_atfork", "group__XBT__thread.html#gad4f77b979102bcbb4dc49538481146ac", null ],
    [ "xbt_os_get_numcores", "group__XBT__thread.html#ga737321f05368f70c51d5d4c939b3aa11", null ]
];