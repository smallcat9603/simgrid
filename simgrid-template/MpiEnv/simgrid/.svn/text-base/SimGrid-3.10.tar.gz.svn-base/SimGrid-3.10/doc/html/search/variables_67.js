var searchData=
[
  ['get_5favailable_5fspeed',['get_available_speed',['../structsurf__workstation__model__extension__public.html#ae6ed8c858e3d713fc7f1ba8f04bd1008',1,'surf_workstation_model_extension_public']]],
  ['get_5fconsumed_5fenergy',['get_consumed_energy',['../structsurf__workstation__model__extension__public.html#aab3ed59f084f1e1b1f50585df5fe7b6d',1,'surf_workstation_model_extension_public']]],
  ['get_5fcurrent_5fpower_5fpeak',['get_current_power_peak',['../structsurf__workstation__model__extension__public.html#a1d53057051b5a38f76ada79e77f0a7a8',1,'surf_workstation_model_extension_public']]],
  ['get_5flink_5fbandwidth',['get_link_bandwidth',['../structsurf__workstation__model__extension__public.html#a564334f9eb1e783fa1f561bdf3a5aae0',1,'surf_workstation_model_extension_public']]],
  ['get_5flink_5flatency',['get_link_latency',['../structsurf__workstation__model__extension__public.html#a660cd47d3c8ef9bdd3dcb1bfd81f8e57',1,'surf_workstation_model_extension_public']]],
  ['get_5fnb_5fpstates',['get_nb_pstates',['../structsurf__workstation__model__extension__public.html#abfe09c2f5cb3774077c701c9c6cb62e6',1,'surf_workstation_model_extension_public']]],
  ['get_5fpower_5fpeak_5fat',['get_power_peak_at',['../structsurf__workstation__model__extension__public.html#aad3d20d4803ed5677f542b6f44162924',1,'surf_workstation_model_extension_public']]],
  ['get_5fremains',['get_remains',['../structsurf__model.html#adf9644f3b9b404f36973a25bfee0e761',1,'surf_model']]],
  ['get_5froute',['get_route',['../structsurf__workstation__model__extension__public.html#a84cdf3b9de17ceef028da789296fd1ae',1,'surf_workstation_model_extension_public']]],
  ['get_5fspeed',['get_speed',['../structsurf__workstation__model__extension__public.html#a4360bd7e469801b2adc37c56edccfeca',1,'surf_workstation_model_extension_public']]],
  ['get_5fstate',['get_state',['../structsurf__workstation__model__extension__public.html#a13bf38fd96228f099d5edbe6f55dafff',1,'surf_workstation_model_extension_public']]]
];
