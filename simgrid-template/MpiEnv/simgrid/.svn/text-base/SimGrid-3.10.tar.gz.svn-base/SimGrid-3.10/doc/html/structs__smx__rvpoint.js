var structs__smx__rvpoint =
[
    [ "name", "structs__smx__rvpoint.html#aa62b404646a9748768dcc3ed3ed52424", null ],
    [ "comm_fifo", "structs__smx__rvpoint.html#ac926954d89514d291ba00b48563c0222", null ],
    [ "data", "structs__smx__rvpoint.html#abfc69646b084de488b6af1ba9b9131a8", null ],
    [ "permanent_receiver", "structs__smx__rvpoint.html#ae08262b4ac90c0e0e8026aa4586dc7ef", null ],
    [ "done_comm_fifo", "structs__smx__rvpoint.html#a96a10df3eb5e0cb0693629297832148d", null ]
];