var group__XBT__swag__func =
[
    [ "xbt_swag_reset", "group__XBT__swag__func.html#ga178b8841e1a3e2561f5b73fbfdecdfa1", null ],
    [ "xbt_swag_insert", "group__XBT__swag__func.html#ga1bb1fb6d0e53c58a6d5c9ceac94339b6", null ],
    [ "xbt_swag_offset", "group__XBT__swag__func.html#ga96193348bca3b2b0840cbc122d8516f7", null ],
    [ "xbt_swag_new", "group__XBT__swag__func.html#ga11b0c605fb84243e1c399831c9efbf6c", null ],
    [ "xbt_swag_free", "group__XBT__swag__func.html#ga936859aae1ee95f8cfb9f32047dc482d", null ],
    [ "xbt_swag_init", "group__XBT__swag__func.html#ga08da2ee0936e19da57695b5d99007c64", null ],
    [ "xbt_swag_insert_at_head", "group__XBT__swag__func.html#ga19c8dc8c1637bb0fce94c4bc38b7d088", null ],
    [ "xbt_swag_insert_at_tail", "group__XBT__swag__func.html#gae5919f7e25c402ac3079d792e033a1fb", null ],
    [ "xbt_swag_remove", "group__XBT__swag__func.html#gabce3d24a60fbd2e2cbd31df6612418a3", null ],
    [ "xbt_swag_extract", "group__XBT__swag__func.html#ga008f75ad3c220b326121e44a6cadb6d3", null ],
    [ "xbt_swag_size", "group__XBT__swag__func.html#gaef55e706dcbabb605cf71e522caa82e6", null ]
];