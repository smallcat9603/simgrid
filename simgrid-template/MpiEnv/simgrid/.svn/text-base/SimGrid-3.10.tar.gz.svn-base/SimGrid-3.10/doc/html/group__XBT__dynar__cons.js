var group__XBT__dynar__cons =
[
    [ "xbt_dynar_t", "group__XBT__dynar__cons.html#gac826571988d2b63ae225e5c62ecdbc79", null ],
    [ "xbt_dynar_new", "group__XBT__dynar__cons.html#ga69ab371f667dfe5aa51fb612b9afaca5", null ],
    [ "xbt_dynar_free", "group__XBT__dynar__cons.html#ga9b7808eb7a87dcf331a467f323ae16a6", null ],
    [ "xbt_dynar_free_voidp", "group__XBT__dynar__cons.html#gacab2aaa46863a53beaa1637bd41995aa", null ],
    [ "xbt_dynar_free_container", "group__XBT__dynar__cons.html#ga7bc3c4dffd7740c9c1ea129d1167c0bc", null ],
    [ "xbt_dynar_shrink", "group__XBT__dynar__cons.html#ga8c1a192e8119147d92eaf873a2861fc0", null ]
];