var group__msg__simulation =
[
    [ "MSG_init", "group__msg__simulation.html#gab394a1043a25ec62f498c097d805f0a1", null ],
    [ "msg_error_t", "group__msg__simulation.html#gaf79b56c0bd3b78b539b0cb4c12e56425", [
      [ "MSG_OK", "group__msg__simulation.html#ggaf79b56c0bd3b78b539b0cb4c12e56425a7db209a18c6374183567534787dccc1b", null ],
      [ "MSG_TIMEOUT", "group__msg__simulation.html#ggaf79b56c0bd3b78b539b0cb4c12e56425a2f90300a07b9b18285e1897b1fabfd06", null ],
      [ "MSG_TRANSFER_FAILURE", "group__msg__simulation.html#ggaf79b56c0bd3b78b539b0cb4c12e56425a373b92dc6a498dea6ab408fb1670386f", null ],
      [ "MSG_HOST_FAILURE", "group__msg__simulation.html#ggaf79b56c0bd3b78b539b0cb4c12e56425a69965b44e0393c3ba81482bb975c55e5", null ],
      [ "MSG_TASK_CANCELED", "group__msg__simulation.html#ggaf79b56c0bd3b78b539b0cb4c12e56425a115b6882d73de65d775aa8c7f1abaf70", null ]
    ] ],
    [ "MSG_launch_application", "group__msg__simulation.html#ga012d470de7974da7262d0020e00117e9", null ],
    [ "MSG_function_register", "group__msg__simulation.html#ga21e94a4e7b26dea140b0c71a2a4f4352", null ],
    [ "MSG_function_register_default", "group__msg__simulation.html#ga698d00aec4b3d7f8cf90c4d1a4595c9c", null ],
    [ "MSG_get_registered_function", "group__msg__simulation.html#ga61b2e271c59ff50d38de7a0f9858b4b1", null ],
    [ "MSG_create_environment", "group__msg__simulation.html#gae08e089d52a2928680e0957e7152d79d", null ],
    [ "MSG_init_nocheck", "group__msg__simulation.html#ga0dbc6fabf0391c4f193b33befeb8a22e", null ],
    [ "MSG_main", "group__msg__simulation.html#ga638072e92edcf9c5aed498daefed010c", null ],
    [ "MSG_config", "group__msg__simulation.html#ga35037b57281f860b92ed7704d37de78f", null ],
    [ "MSG_process_killall", "group__msg__simulation.html#ga0dedd7962cd7d916406ef45c471f6134", null ],
    [ "MSG_get_clock", "group__msg__simulation.html#gacfeb7fa281abd0ff74b0591937cbb574", null ]
];