var group__m__task__management =
[
    [ "MSG_TASK_UNINITIALIZED", "group__m__task__management.html#ga13f8ac858abd957f5cb2e9a54ad98d76", null ],
    [ "msg_task_t", "group__m__task__management.html#gaa7cd89c7f542d19fd817a614d1c1cc95", null ],
    [ "msg_gpu_task_t", "group__m__task__management.html#ga3ab366f5db21f52c90a265fe83c5c2dd", null ],
    [ "MSG_task_create", "group__m__task__management.html#gaafe2ccabd38b13d1734323f86e40706a", null ],
    [ "MSG_parallel_task_create", "group__m__task__management.html#ga54412e440ff859933bbbcb0204aa5a75", null ],
    [ "MSG_gpu_task_create", "group__m__task__management.html#ga4ed297ea1a968b31be47d45f5f908580", null ],
    [ "MSG_task_get_data", "group__m__task__management.html#gab0ef7c694fcc69282cf4da632ae64d5b", null ],
    [ "MSG_task_set_data", "group__m__task__management.html#ga5a2984b6a34bb725b52ee31cdece56a2", null ],
    [ "MSG_task_set_copy_callback", "group__m__task__management.html#gab4fd7f315f6f7d9297eaad64e67fbf90", null ],
    [ "MSG_task_get_sender", "group__m__task__management.html#ga90a38af4ae02895a5e656c6d2555a63b", null ],
    [ "MSG_task_get_source", "group__m__task__management.html#gabb8f9c3289b341b68af5c789ea659c1e", null ],
    [ "MSG_task_get_name", "group__m__task__management.html#ga2adce7c9dbe8ecab1d6db1fdc420ea80", null ],
    [ "MSG_task_set_name", "group__m__task__management.html#gaa97b99e0176424e3f0afdf239e2f3f32", null ],
    [ "MSG_task_destroy", "group__m__task__management.html#gaf6369e840095c428218e494bf8b6dee6", null ],
    [ "MSG_task_get_compute_duration", "group__m__task__management.html#gae6c900f519f6280a9e7a615a2e47cb96", null ],
    [ "MSG_task_set_compute_duration", "group__m__task__management.html#gab54a9cc669db50dc7229389ac3dc7f1f", null ],
    [ "MSG_task_set_data_size", "group__m__task__management.html#ga3c900ab457b5822c205979097765bc04", null ],
    [ "MSG_task_get_remaining_computation", "group__m__task__management.html#gada131788294fe436d9cc1044319b111f", null ],
    [ "MSG_task_get_remaining_communication", "group__m__task__management.html#ga1f3d2d85e2a7415e26fa12f05b71fc34", null ],
    [ "MSG_task_get_data_size", "group__m__task__management.html#ga5d7514ea11b8a51bad0cbc7ad0636856", null ],
    [ "MSG_task_set_priority", "group__m__task__management.html#ga22cf2562fbb9cad8c5860914c0d8d6dc", null ]
];