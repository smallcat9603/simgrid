var group__XBT__parmap =
[
    [ "xbt_parmap_t", "group__XBT__parmap.html#gaebe875868080812c5e303884551ced62", null ],
    [ "e_xbt_parmap_mode_t", "group__XBT__parmap.html#gacbdbf85f704718b8680f13e56c618e7a", [
      [ "XBT_PARMAP_POSIX", "group__XBT__parmap.html#ggacbdbf85f704718b8680f13e56c618e7aaa076c8a9592fd4f8656a078483688700", null ],
      [ "XBT_PARMAP_FUTEX", "group__XBT__parmap.html#ggacbdbf85f704718b8680f13e56c618e7aaec7bc115136c58098a826d86296d2f7d", null ],
      [ "XBT_PARMAP_BUSY_WAIT", "group__XBT__parmap.html#ggacbdbf85f704718b8680f13e56c618e7aafd6884f2f0271777d1e8ea1db1b29229", null ],
      [ "XBT_PARMAP_DEFAULT", "group__XBT__parmap.html#ggacbdbf85f704718b8680f13e56c618e7aa0329f52f37cdb070e8d64330c7a1b395", null ]
    ] ],
    [ "xbt_parmap_new", "group__XBT__parmap.html#ga939a0ab549af87ff1df13642396d5087", null ],
    [ "xbt_parmap_destroy", "group__XBT__parmap.html#ga3e1c75bd9e1a502350a2d2098dc316bb", null ],
    [ "xbt_parmap_apply", "group__XBT__parmap.html#ga7d2b99167edbcbccb7a514451042f09f", null ],
    [ "xbt_parmap_next", "group__XBT__parmap.html#gac667744f002bbf8d1d8dc32e36d0d308", null ]
];