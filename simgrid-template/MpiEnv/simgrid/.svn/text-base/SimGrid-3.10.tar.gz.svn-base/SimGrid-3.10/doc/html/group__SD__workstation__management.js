var group__SD__workstation__management =
[
    [ "SD_workstation_get_by_name", "group__SD__workstation__management.html#ga1c912ef7ecda05d307afefad0fc759b6", null ],
    [ "SD_workstation_get_list", "group__SD__workstation__management.html#ga2849ed01ae4dc580923fbd6782d9ccf4", null ],
    [ "SD_workstation_get_number", "group__SD__workstation__management.html#gacdc811bb1046b88da230d51c68533ba2", null ],
    [ "SD_workstation_set_data", "group__SD__workstation__management.html#ga63c39639777faf77a8e6c0bd41694fa1", null ],
    [ "SD_workstation_get_data", "group__SD__workstation__management.html#gaed29af2c807f986fccf6d3ad4bf15156", null ],
    [ "SD_workstation_get_name", "group__SD__workstation__management.html#ga229affb29b5472c8f62f054b0def9547", null ],
    [ "SD_workstation_get_properties", "group__SD__workstation__management.html#ga24a4f207e56f070fa83c56d8bb0c35c1", null ],
    [ "SD_workstation_get_property_value", "group__SD__workstation__management.html#ga6977e577293bd72f9e191dd2613b650f", null ],
    [ "SD_workstation_dump", "group__SD__workstation__management.html#ga71b72259a6d31b4445700eb1d21a087a", null ],
    [ "SD_route_get_list", "group__SD__workstation__management.html#gaa9522a1e095218a426cf6c70315fdc9d", null ],
    [ "SD_route_get_size", "group__SD__workstation__management.html#gad28c1465fa8cc17f0d73668ed8dbca4a", null ],
    [ "SD_workstation_get_power", "group__SD__workstation__management.html#ga324f3ae1cea2ae9e52bfb70448361f26", null ],
    [ "SD_workstation_get_available_power", "group__SD__workstation__management.html#gadfd3673bc4bc5011babfd0247d45ef28", null ],
    [ "SD_workstation_get_access_mode", "group__SD__workstation__management.html#ga68c974556d55dc2ae760fde9408a32e6", null ],
    [ "SD_workstation_set_access_mode", "group__SD__workstation__management.html#gac00d8cc9c460d532aedfb9ba8fc49c66", null ],
    [ "SD_workstation_get_computation_time", "group__SD__workstation__management.html#ga9caaba45417c65427ee74da841dd14e2", null ],
    [ "SD_route_get_current_latency", "group__SD__workstation__management.html#ga224866561ec8000a495faea7c5e25b48", null ],
    [ "SD_route_get_current_bandwidth", "group__SD__workstation__management.html#gad52c195122d5cd98331a3838c52d4d81", null ],
    [ "SD_route_get_communication_time", "group__SD__workstation__management.html#ga0983ee235addaee99467ef4c4f97966b", null ],
    [ "SD_workstation_get_current_task", "group__SD__workstation__management.html#ga0e4d5fa0f15423b8c1e55abfecd25164", null ],
    [ "SD_workstation_get_storage_list", "group__SD__workstation__management.html#ga5bb5798685fdcd82966f1238c620e2a0", null ]
];