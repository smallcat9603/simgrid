var searchData=
[
  ['process_20management_20functions',['Process Management Functions',['../group__m__process__management.html',1,'']]],
  ['pid',['pid',['../structxbt__ex__t.html#a1d67c080063f5af389c3b23c381c240f',1,'xbt_ex_t']]],
  ['platform_20description',['Platform Description',['../platform.html',1,'use']]],
  ['packet_20level_20simulation',['Packet level simulation',['../pls.html',1,'advanced']]],
  ['priority',['priority',['../structsurf__action.html#ad856ef7cb77971a29ce0691b52bfd89e',1,'surf_action']]],
  ['procname',['procname',['../structxbt__ex__t.html#a2b10084a06349fff9725b7de494027a5',1,'xbt_ex_t']]],
  ['process_20management_20functions',['Process Management Functions',['../group__simix__process__management.html',1,'']]],
  ['portable_20context_20implementation',['Portable context implementation',['../group__XBT__context.html',1,'']]],
  ['perl_2dlike_20use_20of_20dynars',['Perl-like use of dynars',['../group__XBT__dynar__perl.html',1,'']]],
  ['parallel_20map',['Parallel map',['../group__XBT__parmap.html',1,'']]],
  ['peer',['Peer',['../group__XBT__peer.html',1,'']]]
];
