var structsurf__action__state =
[
    [ "ready_action_set", "structsurf__action__state.html#a037da16821384bfb2364d03d7bc7c6b2", null ],
    [ "running_action_set", "structsurf__action__state.html#a25766c647f7fadf3b54cdd5f7ab81957", null ],
    [ "failed_action_set", "structsurf__action__state.html#afd75fc8c3f9c0427127d33cf6c0514d8", null ],
    [ "done_action_set", "structsurf__action__state.html#ae22e8832c0918dc4942f1d918103e186", null ]
];