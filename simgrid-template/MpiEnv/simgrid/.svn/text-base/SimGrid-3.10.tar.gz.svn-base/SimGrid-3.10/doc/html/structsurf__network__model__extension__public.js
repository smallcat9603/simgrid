var structsurf__network__model__extension__public =
[
    [ "communicate", "structsurf__network__model__extension__public.html#aa966bc991d790f93aad9388ec7667138", null ],
    [ "get_route", "structsurf__network__model__extension__public.html#a6714ba944b2ad344f1ca39243ebede17", null ],
    [ "get_link_bandwidth", "structsurf__network__model__extension__public.html#a605fe2fe5f6d1311179a36dbf67931be", null ],
    [ "get_link_latency", "structsurf__network__model__extension__public.html#a76c9975d0433f0df43694f075b8fe177", null ],
    [ "link_shared", "structsurf__network__model__extension__public.html#a5ff6d0954f860e74ddc1d0b244f10f4e", null ],
    [ "add_traces", "structsurf__network__model__extension__public.html#ab6f43aef34d2a59f87990905d8079ce2", null ]
];