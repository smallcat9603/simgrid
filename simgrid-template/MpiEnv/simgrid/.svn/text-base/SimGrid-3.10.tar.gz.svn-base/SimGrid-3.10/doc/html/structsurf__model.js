var structsurf__model =
[
    [ "name", "structsurf__model.html#a285237be60a0c75c56d50f754f10ca1b", null ],
    [ "states", "structsurf__model.html#a0e84008d3c39ef70dbdb98a9de1bcf48", null ],
    [ "action_state_get", "structsurf__model.html#ad6398c4a857042569f6943e95d4dcec4", null ],
    [ "action_state_set", "structsurf__model.html#a969312b9fd1533e9fb8488059522d760", null ],
    [ "action_get_start_time", "structsurf__model.html#a2ab1dc2a56a9950a1fc5afd4b09013f9", null ],
    [ "action_get_finish_time", "structsurf__model.html#a9bcb1343173e301eb3e861d8cefe30c1", null ],
    [ "action_unref", "structsurf__model.html#acb6cffe534dbfcfb5c3fefc5b714e623", null ],
    [ "action_cancel", "structsurf__model.html#aae5c7f6115a8e8f0c2c7dbd168dd8a8e", null ],
    [ "action_recycle", "structsurf__model.html#afdbd4f9c98ca4af207c89ebb29c9d8bb", null ],
    [ "action_data_set", "structsurf__model.html#ade0d9846b3a3e6321e87a51fc257116b", null ],
    [ "suspend", "structsurf__model.html#a90af557a210c80ed385fc4a0f4b3a882", null ],
    [ "resume", "structsurf__model.html#a8f0b61e06575462b3c5cbf1a22f3e859", null ],
    [ "is_suspended", "structsurf__model.html#af65ddbc8ce59a3e2e7e26098b5ba6552", null ],
    [ "set_max_duration", "structsurf__model.html#a4702f5e90dc62742ec188695e0ff1c72", null ],
    [ "set_priority", "structsurf__model.html#a34f89ec266f457c37000f52cdd354a08", null ],
    [ "set_category", "structsurf__model.html#a2fe3155ae5dfb3782e1e7b01dc90a988", null ],
    [ "get_remains", "structsurf__model.html#adf9644f3b9b404f36973a25bfee0e761", null ],
    [ "gap_remove", "structsurf__model.html#a8dea34276bb3ba16c8c951579d4e46f1", null ],
    [ "model_private", "structsurf__model.html#a1b01e2fdca338d8a3180ae3ab054c337", null ],
    [ "extension", "structsurf__model.html#a9170f75c0ec35d6b9655a11afb171cc5", null ]
];