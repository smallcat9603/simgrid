var structs__smx__storage__priv =
[
    [ "data", "structs__smx__storage__priv.html#a591cd4633cc845c42cfef995a73a32bb", null ]
];