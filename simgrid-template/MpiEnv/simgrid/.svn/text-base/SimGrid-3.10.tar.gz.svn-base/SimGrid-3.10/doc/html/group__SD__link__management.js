var group__SD__link__management =
[
    [ "SD_link_get_list", "group__SD__link__management.html#gae6a4a20a3269c3595a195d24f220fb40", null ],
    [ "SD_link_get_number", "group__SD__link__management.html#ga8f5ff7ea86c621aa77f44e913222613d", null ],
    [ "SD_link_get_data", "group__SD__link__management.html#ga4f56602832da18405e8d0e2653f0744c", null ],
    [ "SD_link_set_data", "group__SD__link__management.html#ga180c8056827783104c4cecce3acc9b23", null ],
    [ "SD_link_get_name", "group__SD__link__management.html#gace788d7f0b4b57c5af0b8a5025929780", null ],
    [ "SD_link_get_current_bandwidth", "group__SD__link__management.html#ga4bdb09a991d2366f38c303ed2e48c885", null ],
    [ "SD_link_get_current_latency", "group__SD__link__management.html#ga61b0106214ae990e8f4c9aaecfbc0779", null ],
    [ "SD_link_get_sharing_policy", "group__SD__link__management.html#gaab6c4e1b06d62ed57157b508561b28c8", null ]
];