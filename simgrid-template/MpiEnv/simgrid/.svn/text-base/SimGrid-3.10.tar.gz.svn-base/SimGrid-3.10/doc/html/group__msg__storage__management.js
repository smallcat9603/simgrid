var group__msg__storage__management =
[
    [ "msg_storage_t", "group__msg__storage__management.html#ga13125793869304d581f31a0beb3e143d", null ],
    [ "MSG_storage_get_name", "group__msg__storage__management.html#ga4e3dbb8ae3bda7ba80df6c32c4816926", null ],
    [ "MSG_storage_get_free_size", "group__msg__storage__management.html#gab65b4a69185c6e80ed1da21012c7f100", null ],
    [ "MSG_storage_get_used_size", "group__msg__storage__management.html#gae0d57e843712319835f31fcf8c23894b", null ],
    [ "MSG_storage_get_properties", "group__msg__storage__management.html#ga28017dad8a2c6f1fe10b52b208d4a36e", null ],
    [ "MSG_storage_set_property_value", "group__msg__storage__management.html#gab104363d9be84030d4e301e169e8cd6b", null ],
    [ "MSG_storage_get_by_name", "group__msg__storage__management.html#ga546b28d8dcd4f9b9f9206fa49c97fb23", null ],
    [ "MSG_storages_as_dynar", "group__msg__storage__management.html#ga3d0280ddcf0026cee8837d30eebb6c90", null ],
    [ "MSG_storage_set_data", "group__msg__storage__management.html#ga6355cbf57e26d99c0ba021b8ba97514f", null ],
    [ "MSG_storage_get_content", "group__msg__storage__management.html#gab542d642be87d52dd647b77ea3f44b74", null ]
];