var group__msg__file__management =
[
    [ "msg_file_t", "group__msg__file__management.html#ga87e0d76d9428e822d9a67e676c8a2775", null ],
    [ "MSG_file_set_data", "group__msg__file__management.html#ga902c9e5bdda07488bdbb310303c40551", null ],
    [ "MSG_file_get_data", "group__msg__file__management.html#ga460af619ebd92cebe5d5b812f91eb73c", null ],
    [ "MSG_file_dump", "group__msg__file__management.html#ga026a21b86128403f92c3f4730c68d153", null ],
    [ "MSG_file_read", "group__msg__file__management.html#ga3c6c221ab91ae0213ad967204c882882", null ],
    [ "MSG_file_write", "group__msg__file__management.html#ga3b1606c3e01721f3eab49f236741f208", null ],
    [ "MSG_file_open", "group__msg__file__management.html#gae05ac2e6382893dc94ed610408b19c95", null ],
    [ "MSG_file_close", "group__msg__file__management.html#ga8087da2271bceabefcc6d6636decb750", null ],
    [ "MSG_file_unlink", "group__msg__file__management.html#ga886ea23939db224929e122d363ed91cb", null ],
    [ "MSG_file_get_size", "group__msg__file__management.html#gabb010052e11b12c6b6d8169cdff66c82", null ],
    [ "MSG_file_ls", "group__msg__file__management.html#gad55ef25a4f6e484f4874d9cdc306c869", null ]
];