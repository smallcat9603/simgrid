var searchData=
[
  ['pid',['pid',['../structxbt__ex__t.html#a1d67c080063f5af389c3b23c381c240f',1,'xbt_ex_t']]],
  ['priority',['priority',['../structsurf__action.html#ad856ef7cb77971a29ce0691b52bfd89e',1,'surf_action']]],
  ['procname',['procname',['../structxbt__ex__t.html#a2b10084a06349fff9725b7de494027a5',1,'xbt_ex_t']]]
];
