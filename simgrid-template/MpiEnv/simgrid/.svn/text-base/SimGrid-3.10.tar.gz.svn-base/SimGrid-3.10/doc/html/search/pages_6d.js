var searchData=
[
  ['modifying_20the_20cmake_20files',['Modifying the cmake files',['../inside_cmake.html',1,'internals']]]
];
