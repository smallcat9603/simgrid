var group__XBT__error =
[
    [ "xbt_assert", "group__XBT__error.html#gadd837b8bf67480aea409a8580072f0be", null ],
    [ "xbt_abort", "group__XBT__error.html#gaca8531c4c752e94c638c030c80528021", null ],
    [ "xbt_die", "group__XBT__error.html#ga9bf4916de59dbf2c5bc790e85df7c189", null ]
];