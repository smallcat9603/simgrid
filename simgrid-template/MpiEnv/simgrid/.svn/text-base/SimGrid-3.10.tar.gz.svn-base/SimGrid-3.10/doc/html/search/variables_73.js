var searchData=
[
  ['set_5fcategory',['set_category',['../structsurf__model.html#a2fe3155ae5dfb3782e1e7b01dc90a988',1,'surf_model']]],
  ['set_5fmax_5fduration',['set_max_duration',['../structsurf__model.html#a4702f5e90dc62742ec188695e0ff1c72',1,'surf_model']]],
  ['set_5fpower_5fpeak_5fat',['set_power_peak_at',['../structsurf__workstation__model__extension__public.html#ae83fe4298008ce08652906ccf51ad66e',1,'surf_workstation_model_extension_public']]],
  ['set_5fpriority',['set_priority',['../structsurf__model.html#a34f89ec266f457c37000f52cdd354a08',1,'surf_model']]],
  ['sleep',['sleep',['../structsurf__workstation__model__extension__public.html#a21f808bbbafa9bf838c71b5e54501465',1,'surf_workstation_model_extension_public']]],
  ['start',['start',['../structsurf__action.html#ab81d9f768089a74b58910ad81f50d5f7',1,'surf_action']]],
  ['states',['states',['../structsurf__model.html#a0e84008d3c39ef70dbdb98a9de1bcf48',1,'surf_model']]],
  ['status',['status',['../structs__xbt__parmap.html#afe6c4afdbdfecc9dc4cc141e264e1fa7',1,'s_xbt_parmap']]],
  ['suspend',['suspend',['../structsurf__model.html#a90af557a210c80ed385fc4a0f4b3a882',1,'surf_model']]]
];
