var searchData=
[
  ['ready_5faction_5fset',['ready_action_set',['../structsurf__action__state.html#a037da16821384bfb2364d03d7bc7c6b2',1,'surf_action_state']]],
  ['remains',['remains',['../structsurf__action.html#a524498b274bd63b350e368a57105f47f',1,'surf_action']]],
  ['resume',['resume',['../structsurf__model.html#a8f0b61e06575462b3c5cbf1a22f3e859',1,'surf_model']]],
  ['running_5faction_5fset',['running_action_set',['../structsurf__action__state.html#a25766c647f7fadf3b54cdd5f7ab81957',1,'surf_action_state']]]
];
