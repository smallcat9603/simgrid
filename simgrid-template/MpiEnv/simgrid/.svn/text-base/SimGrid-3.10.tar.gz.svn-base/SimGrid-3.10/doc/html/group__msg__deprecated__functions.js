var group__msg__deprecated__functions =
[
    [ "MSG_get_errno", "group__msg__deprecated__functions.html#ga4abdb2c7da1b9d89187ce51211db3f25", null ],
    [ "MSG_task_put", "group__msg__deprecated__functions.html#ga3e310a2bf7efc32d3aac8dad2eacd71d", null ],
    [ "MSG_task_put_bounded", "group__msg__deprecated__functions.html#ga6e5db824a4317c3a1279eeaa79b6511d", null ],
    [ "MSG_task_put_with_timeout", "group__msg__deprecated__functions.html#gac979ed68d1b602dd04169cbed23828a9", null ],
    [ "MSG_task_probe_from", "group__msg__deprecated__functions.html#ga99bfe9edc985c6d2cce3947f81780660", null ],
    [ "MSG_task_Iprobe", "group__msg__deprecated__functions.html#gae72af17e16cda4efcfad301a4170accd", null ],
    [ "MSG_task_probe_from_host", "group__msg__deprecated__functions.html#gaa44c47c7ed2f78243eca7379437e1cc0", null ],
    [ "MSG_task_get_from_host", "group__msg__deprecated__functions.html#gad09e64171486db6b0004653125313971", null ],
    [ "MSG_task_get", "group__msg__deprecated__functions.html#ga1ae6d2a80ca4f35d7a19215f409ce00f", null ],
    [ "MSG_task_get_with_timeout", "group__msg__deprecated__functions.html#ga48bf7268e2f079ba1ad51a00209028cd", null ]
];