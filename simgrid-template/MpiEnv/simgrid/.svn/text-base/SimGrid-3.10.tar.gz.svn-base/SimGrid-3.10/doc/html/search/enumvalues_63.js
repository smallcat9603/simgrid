var searchData=
[
  ['cancel_5ferror',['cancel_error',['../group__XBT__ex.html#ggaa45fec59aa57056784554a7f998f0854a78725e8318a373565146a9c29698eb30',1,'ex.h']]]
];
