var structs__xbt__dict__cursor =
[
    [ "current", "structs__xbt__dict__cursor.html#a4c64e66fcdf566bcc46385d7a78316ca", null ],
    [ "line", "structs__xbt__dict__cursor.html#a349b536ba2a66ab40fd69a92d5b489d1", null ],
    [ "dict", "structs__xbt__dict__cursor.html#ab1ede032c9b987a3af7efb95f577d9e9", null ]
];