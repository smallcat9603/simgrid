var structs__xbt__parmap =
[
    [ "status", "structs__xbt__parmap.html#afe6c4afdbdfecc9dc4cc141e264e1fa7", null ],
    [ "work", "structs__xbt__parmap.html#acbf2e11c9c8d053907e5bc6f8e4d396d", null ],
    [ "thread_counter", "structs__xbt__parmap.html#a4cb1478d076f1df7aa59518292b9300e", null ],
    [ "num_workers", "structs__xbt__parmap.html#a4610f24b4081b535323b5ae767221137", null ],
    [ "workers", "structs__xbt__parmap.html#a8c93b6fa9e0bdfaf8322245e731bc2af", null ],
    [ "fun", "structs__xbt__parmap.html#ab41017148fff9bfd45f1e4562cd8881f", null ],
    [ "data", "structs__xbt__parmap.html#ae218d5ac5ff8b9a5910f445627cb248e", null ],
    [ "index", "structs__xbt__parmap.html#ac583971bdbd4b8d9693e6bb539da69fe", null ],
    [ "ready_cond", "structs__xbt__parmap.html#a4cf0a8a6d432cf3f1d9d5706d9c101e6", null ],
    [ "ready_mutex", "structs__xbt__parmap.html#ae87660dc030d4dd525227abcd178f67d", null ],
    [ "done_cond", "structs__xbt__parmap.html#a7abf26f2438db8b96cccabfe2866aece", null ],
    [ "done_mutex", "structs__xbt__parmap.html#a82dd2440e5bd6fbb9f5001ae9506e0a0", null ],
    [ "mode", "structs__xbt__parmap.html#ac414c60f2d3a61b47e436bfb96245969", null ],
    [ "master_wait_f", "structs__xbt__parmap.html#a675dabf4d9e2117c079aa3dcf1c82678", null ],
    [ "worker_signal_f", "structs__xbt__parmap.html#a9ba6b2ab3c8e1f943d9308c77c4f13ec", null ],
    [ "master_signal_f", "structs__xbt__parmap.html#a5cf66c7f69b8cf8e5546561d5feddfb5", null ],
    [ "worker_wait_f", "structs__xbt__parmap.html#a5524248ea1a35b7094e3c898e293bf0d", null ]
];