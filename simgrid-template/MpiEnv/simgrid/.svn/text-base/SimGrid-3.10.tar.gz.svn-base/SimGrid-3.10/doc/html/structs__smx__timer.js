var structs__smx__timer =
[
    [ "date", "structs__smx__timer.html#a7d8a1896083cb223792d428eaca62593", null ],
    [ "func", "structs__smx__timer.html#add3f486b25914ecf6d688bde9c6abd35", null ],
    [ "args", "structs__smx__timer.html#a36727fc1f8a9910a4d38f62bdc96d27d", null ]
];