var group__XBT__syscall =
[
    [ "xbt_new", "group__XBT__syscall.html#ga1d356d21c8a37c3e19de37d5f7896810", null ],
    [ "xbt_new0", "group__XBT__syscall.html#gaaea21518b543392c869f6564c36cdc2b", null ],
    [ "__attribute__", "group__XBT__syscall.html#gab6d5dfd5b7461f3942dfdd1eda223237", null ],
    [ "xbt_backtrace_display_current", "group__XBT__syscall.html#ga36813e215c49af92c8a62dd8286d6421", null ],
    [ "xbt_free_ref", "group__XBT__syscall.html#gadc6cc4c3185be3635bb1ef2d9528f67a", null ]
];