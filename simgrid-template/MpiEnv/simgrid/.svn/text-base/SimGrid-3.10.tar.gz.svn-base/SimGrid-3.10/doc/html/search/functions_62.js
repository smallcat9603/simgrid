var searchData=
[
  ['bprintf',['bprintf',['../group__XBT__str.html#ga6f0a0c16ffed231430899dabdb426ac6',1,'simgrid_config.h']]],
  ['bvprintf',['bvprintf',['../group__XBT__str.html#ga2faec67938497d455b6ab3ccb69d7fb3',1,'bvprintf(const char *fmt, va_list ap):&#160;snprintf.c'],['../group__XBT__str.html#ga2faec67938497d455b6ab3ccb69d7fb3',1,'bvprintf(const char *fmt, va_list ap):&#160;snprintf.c']]]
];
