var structxbt__boolean__couple =
[
    [ "true_val", "structxbt__boolean__couple.html#a48c1494b9e7d77ca03e866e37db3bf4e", null ],
    [ "false_val", "structxbt__boolean__couple.html#ae1dc08ae1e8037e7a42de0a2c304a510", null ]
];