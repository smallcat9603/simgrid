var searchData=
[
  ['process_20management_20functions',['Process Management Functions',['../group__m__process__management.html',1,'']]],
  ['process_20management_20functions',['Process Management Functions',['../group__simix__process__management.html',1,'']]],
  ['portable_20context_20implementation',['Portable context implementation',['../group__XBT__context.html',1,'']]],
  ['perl_2dlike_20use_20of_20dynars',['Perl-like use of dynars',['../group__XBT__dynar__perl.html',1,'']]],
  ['parallel_20map',['Parallel map',['../group__XBT__parmap.html',1,'']]],
  ['peer',['Peer',['../group__XBT__peer.html',1,'']]]
];
