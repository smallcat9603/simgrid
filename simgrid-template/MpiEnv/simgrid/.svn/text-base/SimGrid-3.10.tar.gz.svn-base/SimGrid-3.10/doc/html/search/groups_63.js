var searchData=
[
  ['communication_20management_20functions',['Communication Management Functions',['../group__simix__comm__management.html',1,'']]],
  ['create_20a_20new_20api',['Create a new API',['../group__SURF__build__api.html',1,'']]],
  ['configuration_20type_20declaration_20and_20memory_20management',['Configuration type declaration and memory management',['../group__XBT__cfg__decl.html',1,'']]],
  ['configuration_20support',['Configuration support',['../group__XBT__config.html',1,'']]],
  ['cursors_20on_20dictionaries',['Cursors on dictionaries',['../group__XBT__dict__curs.html',1,'']]],
  ['cursors_20on_20dynar',['Cursors on dynar',['../group__XBT__dynar__cursor.html',1,'']]]
];
