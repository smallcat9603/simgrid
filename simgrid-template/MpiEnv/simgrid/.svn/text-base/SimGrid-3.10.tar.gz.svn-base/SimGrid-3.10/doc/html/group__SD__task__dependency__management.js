var group__SD__task__dependency__management =
[
    [ "SD_task_dependency_add", "group__SD__task__dependency__management.html#gaeaa883b0561beefb647c5c4280299138", null ],
    [ "SD_task_dependency_remove", "group__SD__task__dependency__management.html#ga3a22709b38b7a4eb86317e334a8110e0", null ],
    [ "SD_task_dependency_get_name", "group__SD__task__dependency__management.html#ga5e94f0a64b796de2fb3e7164bd4c7173", null ],
    [ "SD_task_dependency_get_data", "group__SD__task__dependency__management.html#gaa1bdcdfefbf9b19e03cf90376d6fbbb0", null ],
    [ "SD_task_dependency_exists", "group__SD__task__dependency__management.html#gad492251b41fcd05684d88359c26656e1", null ]
];