var structs__smx__simcall =
[
    [ "call", "structs__smx__simcall.html#aea676664d5c35ed93b2e7db5fb5b7af0", null ],
    [ "issuer", "structs__smx__simcall.html#aea6fc0eab72eeefd06fde74c99b18642", null ],
    [ "mc_value", "structs__smx__simcall.html#a6589d869f55ec4d25b15084ee546c62f", null ],
    [ "args", "structs__smx__simcall.html#a0273369261c794611caa5d9c894d1e9f", null ],
    [ "result", "structs__smx__simcall.html#a7f99321629e2507703d080f551d2bce3", null ],
    [ "param1", "structs__smx__simcall.html#a0ce0a63ee6e7b4eb4c04a8f7d7959216", null ],
    [ "param2", "structs__smx__simcall.html#a02a3f6593bf1accfb5dee59b8d9fa626", null ],
    [ "result", "structs__smx__simcall.html#a4af1be7a26094becfc74f248fff0a14b", null ],
    [ "new_api", "structs__smx__simcall.html#abfcd8103f220e732b70dbbaa8abf08d2", null ]
];