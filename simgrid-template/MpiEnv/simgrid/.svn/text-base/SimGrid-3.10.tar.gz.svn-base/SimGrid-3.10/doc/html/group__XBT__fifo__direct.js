var group__XBT__fifo__direct =
[
    [ "xbt_fifo_foreach", "group__XBT__fifo__direct.html#ga7062f0aae3a97fa72fcf86673675d434", null ],
    [ "xbt_fifo_new_item", "group__XBT__fifo__direct.html#gad9f577f95ac147ed876083d60166a662", null ],
    [ "xbt_fifo_set_item_content", "group__XBT__fifo__direct.html#ga3a95882cc4858a10fa29216c939eb1b4", null ],
    [ "xbt_fifo_get_item_content", "group__XBT__fifo__direct.html#ga601af16f78f6f1753477ce8e91eece01", null ],
    [ "xbt_fifo_free_item", "group__XBT__fifo__direct.html#ga4bfc376902e2e15da4acb31c2ac77d84", null ],
    [ "xbt_fifo_push_item", "group__XBT__fifo__direct.html#gae1266d2dc81fc9d46334500682756b93", null ],
    [ "xbt_fifo_pop_item", "group__XBT__fifo__direct.html#ga32cfb8161a224dafafbf3f667d8257aa", null ],
    [ "xbt_fifo_unshift_item", "group__XBT__fifo__direct.html#gab5d6b760390ffc095f35f50e5bfd890a", null ],
    [ "xbt_fifo_shift_item", "group__XBT__fifo__direct.html#ga46dbde2e3359af8a79f2d4da7582d18c", null ],
    [ "xbt_fifo_remove", "group__XBT__fifo__direct.html#gafae46252cee20c382f9ce4f2e2573135", null ],
    [ "xbt_fifo_remove_all", "group__XBT__fifo__direct.html#ga0662ae632f8f72753074f0cf234f8c46", null ],
    [ "xbt_fifo_remove_item", "group__XBT__fifo__direct.html#gabd68f9b13a5e4984224760e9e5afed3b", null ],
    [ "xbt_fifo_get_first_item", "group__XBT__fifo__direct.html#gadde4755e50e84bf3235182227cdc1580", null ],
    [ "xbt_fifo_get_last_item", "group__XBT__fifo__direct.html#ga8cbb245158703f78cab3d076804eaa61", null ],
    [ "xbt_fifo_get_next_item", "group__XBT__fifo__direct.html#ga6fde465c7d19469ee07e28d7ae5f611b", null ],
    [ "xbt_fifo_get_prev_item", "group__XBT__fifo__direct.html#gac47a383a08e9c08cc4dd5bf29cd50994", null ]
];