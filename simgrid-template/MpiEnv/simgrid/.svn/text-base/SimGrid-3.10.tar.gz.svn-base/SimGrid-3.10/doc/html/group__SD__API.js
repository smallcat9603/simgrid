var group__SD__API =
[
    [ "SD Data Types", "group__SD__datatypes__management.html", "group__SD__datatypes__management" ],
    [ "Workstations", "group__SD__workstation__management.html", "group__SD__workstation__management" ],
    [ "Links", "group__SD__link__management.html", "group__SD__link__management" ],
    [ "Tasks", "group__SD__task__management.html", "group__SD__task__management" ],
    [ "Tasks dependencies", "group__SD__task__dependency__management.html", "group__SD__task__dependency__management" ],
    [ "Simulation", "group__SD__simulation.html", "group__SD__simulation" ]
];