var structs__surf__metric__t =
[
    [ "scale", "structs__surf__metric__t.html#aa5f86985c8f96a1d2baa87859e0f18ba", null ],
    [ "peak", "structs__surf__metric__t.html#af60a903ad384de7784fb88505a0c46e0", null ],
    [ "event", "structs__surf__metric__t.html#ac80e5e2206a08ccb13c025788d1a704c", null ]
];