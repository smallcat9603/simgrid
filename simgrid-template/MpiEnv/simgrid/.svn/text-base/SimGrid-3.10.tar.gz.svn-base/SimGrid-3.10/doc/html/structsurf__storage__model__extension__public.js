var structsurf__storage__model__extension__public =
[
    [ "open", "structsurf__storage__model__extension__public.html#a6edd559401a7bb577f9bcc6e5dd14507", null ],
    [ "close", "structsurf__storage__model__extension__public.html#ae83133f18c15e5337b6e2db10a36c8fb", null ],
    [ "read", "structsurf__storage__model__extension__public.html#ac419c1b7d87fbe63da7e3ded0e934758", null ],
    [ "write", "structsurf__storage__model__extension__public.html#a7c8a55abd88a25e9d145e2359f055eb4", null ],
    [ "stat", "structsurf__storage__model__extension__public.html#adb41211decbb6c95a961df19f35e89e9", null ],
    [ "ls", "structsurf__storage__model__extension__public.html#a42319a48e89b0993946e5f682b0985f3", null ],
    [ "get_properties", "structsurf__storage__model__extension__public.html#a24ae807255ef54c187a3081cf92d897d", null ],
    [ "rename", "structsurf__storage__model__extension__public.html#a7d6f3d2b274ee34a45f98ce665b29b30", null ],
    [ "get_content", "structsurf__storage__model__extension__public.html#abe562eab79f101743c22738c64f3063d", null ],
    [ "get_size", "structsurf__storage__model__extension__public.html#a32699c8fc477edbfac34ec0fcb7a7ef3", null ]
];