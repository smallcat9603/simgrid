var group__XBT__API =
[
    [ "Grounding features", "group__XBT__grounding.html", "group__XBT__grounding" ],
    [ "Usual data structures", "group__XBT__adt.html", "group__XBT__adt" ],
    [ "Misc general purposes library components", "group__XBT__misc.html", "group__XBT__misc" ]
];