var group__XBT__fifo =
[
    [ "Fifo constructor and destructor", "group__XBT__fifo__cons.html", "group__XBT__fifo__cons" ],
    [ "Fifo perl-like functions", "group__XBT__fifo__perl.html", "group__XBT__fifo__perl" ],
    [ "Direct access to fifo elements", "group__XBT__fifo__direct.html", "group__XBT__fifo__direct" ],
    [ "Misc fifo functions", "group__XBT__fifo__misc.html", "group__XBT__fifo__misc" ]
];