var structs__xbt__parmap__thread__data =
[
    [ "parmap", "structs__xbt__parmap__thread__data.html#ae1ffd860183ce274286e6895f91a7d98", null ],
    [ "worker_id", "structs__xbt__parmap__thread__data.html#a1b6e07b976fb9e4f73d14287f18a2270", null ]
];