var group__XBT__set__basic =
[
    [ "xbt_set_add", "group__XBT__set__basic.html#ga1db2802704edc8b5d404ca204fc5b34d", null ],
    [ "xbt_set_remove", "group__XBT__set__basic.html#gadd31f4f1a5a5fdce54f3a8bfbc37de8a", null ],
    [ "xbt_set_remove_by_name", "group__XBT__set__basic.html#gac5ac26bcb50f5a22c1b2af1f8a1f49c4", null ],
    [ "xbt_set_get_by_name_or_null", "group__XBT__set__basic.html#ga02fb94d3aa9fcfaae688f61a0ca9cdc2", null ],
    [ "xbt_set_remove_by_name_ext", "group__XBT__set__basic.html#gabda240bc3fa5bc0ac6983b19f4caa5f8", null ],
    [ "xbt_set_remove_by_id", "group__XBT__set__basic.html#ga917c20ea5adb57ca287dd1d48ca12ec7", null ],
    [ "xbt_set_get_by_name", "group__XBT__set__basic.html#gaa5ebcac05554bc6c20129b437851b12e", null ],
    [ "xbt_set_get_by_name_ext", "group__XBT__set__basic.html#ga6a7bc28b3bedbcb05e2a60297c9df8f0", null ],
    [ "xbt_set_get_by_id", "group__XBT__set__basic.html#ga19df8b5e26799112d5aba9f677739138", null ],
    [ "xbt_set_length", "group__XBT__set__basic.html#ga5a1935dab5ad9e2f3c9820e6db7889a7", null ]
];