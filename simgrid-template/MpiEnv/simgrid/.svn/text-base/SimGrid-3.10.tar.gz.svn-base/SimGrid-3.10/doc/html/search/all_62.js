var searchData=
[
  ['bindings',['Bindings',['../bindings.html',1,'advanced']]],
  ['bound_5ferror',['bound_error',['../group__XBT__ex.html#ggaa45fec59aa57056784554a7f998f0854ae2954a4c5a79d65f9f68675fea93376b',1,'ex.h']]],
  ['bprintf',['bprintf',['../group__XBT__str.html#ga6f0a0c16ffed231430899dabdb426ac6',1,'simgrid_config.h']]],
  ['bvprintf',['bvprintf',['../group__XBT__str.html#ga2faec67938497d455b6ab3ccb69d7fb3',1,'bvprintf(const char *fmt, va_list ap):&#160;snprintf.c'],['../group__XBT__str.html#ga2faec67938497d455b6ab3ccb69d7fb3',1,'bvprintf(const char *fmt, va_list ap):&#160;snprintf.c']]]
];
