var searchData=
[
  ['unknown_5ferror',['unknown_error',['../group__XBT__ex.html#ggaa45fec59aa57056784554a7f998f0854a38ca7f2d055a68295cbd837470325f46',1,'ex.h']]],
  ['using_20simgrid',['Using SimGrid',['../use.html',1,'index']]],
  ['usual_20data_20structures',['Usual data structures',['../group__XBT__adt.html',1,'']]],
  ['user_20interface_3a_20changing_20values',['User interface: changing values',['../group__XBT__cfg__use.html',1,'']]],
  ['unit_20testing_20support',['Unit testing support',['../group__XBT__cunit.html',1,'']]]
];
