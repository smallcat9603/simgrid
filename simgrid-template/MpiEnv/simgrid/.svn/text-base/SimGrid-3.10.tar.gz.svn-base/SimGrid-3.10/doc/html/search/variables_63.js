var searchData=
[
  ['category',['category',['../structxbt__ex__t.html#a2fdd312ae1d96663701d743283404924',1,'xbt_ex_t::category()'],['../structsurf__action.html#ad4acecd52a2d4699e5f2145225fc890d',1,'surf_action::category()']]],
  ['cost',['cost',['../structsurf__action.html#a240981003cb7b2ef07b822b07a3e9973',1,'surf_action']]]
];
