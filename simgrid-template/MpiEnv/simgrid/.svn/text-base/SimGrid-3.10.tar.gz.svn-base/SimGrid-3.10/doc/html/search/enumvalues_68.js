var searchData=
[
  ['host_5ferror',['host_error',['../group__XBT__ex.html#ggaa45fec59aa57056784554a7f998f0854a1486a4899ea0336633c33a77c636eea8',1,'ex.h']]]
];
