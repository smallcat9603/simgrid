var group__XBT__config =
[
    [ "User interface: changing values", "group__XBT__cfg__use.html", "group__XBT__cfg__use" ],
    [ "Configuration type declaration and memory management", "group__XBT__cfg__decl.html", "group__XBT__cfg__decl" ],
    [ "Registering stuff", "group__XBT__cfg__register.html", "group__XBT__cfg__register" ],
    [ "Getting the stored values", "group__XBT__cfg__get.html", "group__XBT__cfg__get" ]
];