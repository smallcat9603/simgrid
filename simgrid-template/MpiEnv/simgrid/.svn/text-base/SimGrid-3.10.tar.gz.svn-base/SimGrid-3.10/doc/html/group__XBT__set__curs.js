var group__XBT__set__curs =
[
    [ "xbt_set_foreach", "group__XBT__set__curs.html#ga58f50aee97a03985e1af193fbdea92ba", null ],
    [ "xbt_set_cursor_t", "group__XBT__set__curs.html#ga07bc36055121d6d2b49a483608033827", null ],
    [ "xbt_set_cursor_first", "group__XBT__set__curs.html#ga0ae677ad09fbf19fc8f9343dcc647dc2", null ],
    [ "xbt_set_cursor_step", "group__XBT__set__curs.html#ga1e42bd77295716cac5d3a38f4b7419b1", null ],
    [ "xbt_set_cursor_get_or_free", "group__XBT__set__curs.html#gac4c1fa14c3207e4ad1c9973db97147d5", null ]
];