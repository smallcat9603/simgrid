var group__simix__file__management =
[
    [ "simcall_file_get_data", "group__simix__file__management.html#ga1d4bafa33327c5ce72d7db4a3f1b78d0", null ],
    [ "simcall_file_set_data", "group__simix__file__management.html#ga6a768555110db361a4e78fe04719c408", null ]
];