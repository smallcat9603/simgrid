On Debian-like systems (which includes ubuntu), you need the following
packages: sun-java6-jdk libgcj10-dev. If you cannot find the
libgcj10-dev, try another version, like libgcj9-dev (on Ubuntu before
9.10) or libgcj11-dev (not released yet, but certainly one day).
Please note that you need to activate the contrib and non-free
repositories in Debian, and the universe ones in Ubuntu. Java comes at
this price...
