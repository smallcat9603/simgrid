#pragma once

#include <boost/multiprecision/gmp.hpp>

typedef boost::multiprecision::mpq_rational Rational;
