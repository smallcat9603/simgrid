#pragma once

/**
 * @brief Tests whether the numeric strcmp function works
 */
void test_numeric_strcmp();
