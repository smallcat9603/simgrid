The file pegasus-graphviz is extracted from the pegasus github (see https://github.com/pegasus-isi/pegasus/blob/master/bin/pegasus-graphviz and LICENSE https://github.com/pegasus-isi/pegasus/blob/master/LICENSE )

example usage :

 contrib/pegasus-graphviz workload_profiles/GENOME.d.351024866.5.dax -o /tmp/bla.dot
 dot -Tjpeg -o /tmp/bla.jpg /tmp/bla.dot 
