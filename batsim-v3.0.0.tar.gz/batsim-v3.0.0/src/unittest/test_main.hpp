#pragma once

/**
 * @brief Unit tests entry point (main funciton)
 */
void test_entry_point();
