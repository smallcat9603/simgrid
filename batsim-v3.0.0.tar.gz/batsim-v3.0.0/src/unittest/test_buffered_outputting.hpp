#pragma once

void test_buffered_writer();
void test_pstate_writer();
