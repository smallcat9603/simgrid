# Deprecated
Batsim changelog has moved.

It can now be found [there](https://batsim.readthedocs.io/en/latest/changelog.html)
as part of the [batsim readthedocs](https://batsim.readthedocs.io/en/latest/index.html).
