#!/usr/bin/env bash

batsched -v easy_bf
