#!/usr/bin/env bash

batsim --version
batsim --simgrid-version
batsched --version
robin --version
