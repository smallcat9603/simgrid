.. _redis:

Using Redis
===========

.. todo::
    Write Redis documentation.

    - Redis conventions (what is stored here, existence of prefix)
    - Link to CLI for giving parameters
