.. _cli:

Command-line Interface
======================

.. todo::
   Describe command-line interface.

   How to get it (batsim --help).
   Most common use cases.
