.. _ci:

Continuous Integration
======================

.. todo::
    Document Batsim continuous integration.

    - Where is the CI?
    - How to look at the build logs?
    - How to reproduce a build on your machine?
    - How does it work?
    - How to update the CI?
